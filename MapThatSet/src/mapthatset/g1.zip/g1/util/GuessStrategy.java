package mapthatset.g1.util;

import java.util.ArrayList;

import javax.management.Query;

public class GuessStrategy {

	private ArrayList<Integer> nextQueryList = new ArrayList<Integer>();
	private int numberOfQueries;
	private int overlappingFactor;
	private int highConfidenceLevel;
	private int lowConfidenceLevel;
	private int moderateConfidenceLevel;

	public ArrayList<Integer> deviseStrategy(int queryIndex, int mappingLength,
			ArrayList<Integer> queryResultList,
			ArrayList<Integer> previousQueryList,
			ArrayList<QueryElement> listOfQueryElements) {
		if (queryResultList != null && queryResultList.size() > 0) {
			if (listOfQueryElements == null || listOfQueryElements.size() == 0) {
				listOfQueryElements = preProcessQueryList(listOfQueryElements,
						queryResultList, previousQueryList);
			}
		}

		if (queryIndex == 1) {
			nextQueryList = getFirstQuery(mappingLength);

		} else {
			nextQueryList = getSubsequentQuery(mappingLength, queryResultList,
					previousQueryList, listOfQueryElements);
		}

		listOfQueryElements = postProcessQueryList(listOfQueryElements);
		previousQueryList = nextQueryList;
		return nextQueryList;
	}

	public ArrayList<Integer> getFirstQuery(int mapppingLength) {
		ArrayList<Integer> firstQueryList = new ArrayList<Integer>();
		numberOfQueries = Math.abs(((mapppingLength + (int) (Math
				.sqrt(mapppingLength))) / 2));
		for (int i = 1; i <= numberOfQueries; i++) {
			firstQueryList.add(i);
		}

		return firstQueryList;
	}

	public ArrayList<Integer> getSubsequentQuery(int mappingLength,
			ArrayList<Integer> queryResultList,
			ArrayList<Integer> previousQueryList,
			ArrayList<QueryElement> listOfQueryElements) {
		ArrayList<Integer> subsequenetQueryList = new ArrayList<Integer>();

		if (queryResultList.size() == 1) {
			for (int previousQuery : previousQueryList) {
				QueryElement queryElement = new QueryElement();
				queryElement.setIsResultConfirmed(true);
				queryElement.setMapping(queryResultList.get(0));
				queryElement.setValue(previousQuery);
				listOfQueryElements.add(queryElement);
			}

			int newLengthOfQuerySet = ((mappingLength - previousQueryList
					.size()) / previousQueryList.size());
			if (newLengthOfQuerySet < 1) {
				newLengthOfQuerySet = 1;
			}
			for (int i = previousQueryList.size(); i < newLengthOfQuerySet; i++) {
				subsequenetQueryList.add(i);
			}

		} else if (queryResultList.size() < previousQueryList.size()) {
			listOfQueryElements = processQueryList(listOfQueryElements,
					queryResultList, previousQueryList);
			ArrayList<Integer> tempArray = new ArrayList<Integer>();
			for (int i = 0; i < mappingLength; i++) {
				for (int j = 0; j < listOfQueryElements.size(); j++) {
					if (i == listOfQueryElements.get(j).getValue()) {
						if (listOfQueryElements.get(j).getIsResultConfirmed() == true) {
							continue;
						}
					} else {
						tempArray.add(i);
					}
				}
			}
			ArrayList<Integer> nonResultantArray = new ArrayList<Integer>();
			for (int i = 0; i < previousQueryList.size(); i++) {
				for (int j = 0; j < listOfQueryElements.size(); j++) {
					if (i == listOfQueryElements.get(j).getValue()) {
						if (listOfQueryElements.get(j).getIsResultConfirmed() == true) {
							continue;
						}
					} else {
						nonResultantArray.add(i);
					}
				}
			}
			int overlap = 2;
			for (int i = 0; i < overlap; i++) {
				subsequenetQueryList.add(nonResultantArray.get(i));
			}
			int newLengthOfQuerySet = 4;
			for (int i = previousQueryList.size(); i < previousQueryList.size()
					+ newLengthOfQuerySet; i++) {
				subsequenetQueryList.add(i);
			}

		} else if (queryResultList.size() == previousQueryList.size()) {
			listOfQueryElements = processQueryList(listOfQueryElements,
					queryResultList, previousQueryList);
			int overlap = 4;
			int newLengthOfQuerySet = 4;
			for (int i = previousQueryList.size(); i < previousQueryList.size()
					+ newLengthOfQuerySet; i++) {
				subsequenetQueryList.add(i);
			}

		}
		return subsequenetQueryList;

	}

	public void checkIfElementConfirmed(
			ArrayList<QueryElement> listOfQueryElements) {

	}

	public ArrayList<QueryElement> preProcessQueryList(
			ArrayList<QueryElement> listOfQueryElements,
			ArrayList<Integer> resultList, ArrayList<Integer> queryList) {
		for (int i = 0; i < queryList.size(); i++) {
			QueryElement queryElement = new QueryElement();
			queryElement.setValue(queryList.get(i));
			ArrayList<Integer> listOfPossibleMappings = new ArrayList<Integer>();
			for (int j = 0; j < resultList.size(); j++) {
				listOfPossibleMappings.add(resultList.get(j));
			}
			queryElement.setListOfPossibleMappings(listOfPossibleMappings);
			listOfQueryElements.add(queryElement);
		}
		return listOfQueryElements;
	}

	public ArrayList<QueryElement> processQueryList(
			ArrayList<QueryElement> listOfQueryElements,
			ArrayList<Integer> queryResultList,
			ArrayList<Integer> previousQueryList) {
		ArrayList<QueryElement> newListOfQueryElements = new ArrayList<QueryElement>();
		for (int i = 0; i < previousQueryList.size(); i++) {
			for (int j = 0; j < queryResultList.size(); j++) {
				if (listOfQueryElements != null
						&& listOfQueryElements.size() > 0) {

					for (int k = 0; k < listOfQueryElements.size(); k++) {
						QueryElement queryElement = listOfQueryElements.get(k);
						if (queryElement.getValue() == previousQueryList.get(i)) {
							if (queryElement.getListOfPossibleMappings() != null
									&& queryElement.getListOfPossibleMappings()
											.size() > 0) {
								ArrayList<Integer> listOfMappings = queryElement
										.getListOfPossibleMappings();
								ArrayList<Integer> newListOfMappings = new ArrayList<Integer>();
								for (int p = 1; p <=listOfMappings.size(); p++) {
									if (p == queryResultList.get(j)) {
										newListOfMappings.add(queryResultList
												.get(j));
									} else {

									}
								}
								if (newListOfMappings != null
										&& newListOfMappings.size() > 0) {
									queryElement
											.setListOfPossibleMappings(newListOfMappings);
								}
							}
						}
						newListOfQueryElements.add(queryElement);
					}
				}
			}
		}
		return newListOfQueryElements;
	}

	public ArrayList<QueryElement> postProcessQueryList(
			ArrayList<QueryElement> listOfQueryElements) {
		if (listOfQueryElements != null && listOfQueryElements.size() > 0) {
			for (int i = 0; i < listOfQueryElements.size(); i++) {
				QueryElement queryElement = listOfQueryElements.get(i);
				ArrayList<Integer> listOfMappings = queryElement
						.getListOfPossibleMappings();
				if (listOfMappings.size() == 1) {
					if (queryElement.getIsResultConfirmed() == false) {
						queryElement.setIsResultConfirmed(true);
					}
				}
			}
		}
		return listOfQueryElements;
	}
}

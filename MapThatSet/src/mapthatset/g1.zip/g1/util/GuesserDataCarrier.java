package mapthatset.g1.util;

public class GuesserDataCarrier {

}
